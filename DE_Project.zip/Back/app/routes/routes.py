from fastapi import APIRouter
from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd
from app.utils.train_pipeline import handle_upload
from app.utils.train_pipeline import train_pipeline 

router = APIRouter(prefix="/api/v1")



@router.post("/upload")
async def upload(file : UploadFile = File(...)):
   return await  handle_upload(file)
    


@router.post("/train")
async def train(payload: dict):
    if payload is None:
        raise HTTPException(status_code=422, detail="Invalid payload")
    return await train_pipeline(payload)

