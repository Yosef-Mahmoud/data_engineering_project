
from fastapi import APIRouter
from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd
import uuid


data_storage = {}
async def handle_upload(file : UploadFile = File(...)):
    if not (file.filename.endswith(".csv") or file.filename.endswith(".xlsx")):
        raise HTTPException(
                    status_code=400, 
                    detail="Invalid file format. Please upload a CSV or Excel file."
                )
        
    
    try:
            contents = await file.read()
            if file.filename.endswith(".csv"):
                import io
                df = pd.read_csv(io.BytesIO(contents))
            else:
                import io
                df = pd.read_excel(io.BytesIO(contents))
            
            columns = df.columns.tolist()
            preview_rows = df.head().values.tolist()
            job_id = uuid.uuid4()
            data_storage[job_id] = df
                
    except Exception as e:
            raise HTTPException(status_code=422, detail=f"Could not parse file: {e}")
        
    
    return {"message": "File processed successfully.", "columns": columns, "rows": preview_rows , "job_id": job_id}
        
