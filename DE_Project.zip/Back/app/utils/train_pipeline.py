from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd
import uuid
import io
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.utils import resample
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, precision_score, recall_score, confusion_matrix,
    silhouette_score
)

router = APIRouter()
data_storage = {}

@router.post("/upload")
async def handle_upload(file: UploadFile = File(...)):
    if not (file.filename.endswith(".csv") or file.filename.endswith(".xlsx")):
        raise HTTPException(status_code=400, detail="Invalid file format. Please upload a .csv or .xlsx file.")

    contents = await file.read()
    if len(contents) == 0:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")

    try:
        if file.filename.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        else:
            df = pd.read_excel(io.BytesIO(contents))
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Could not parse file: {e}")

    if df.empty:
        raise HTTPException(status_code=422, detail="The file was parsed but contains no data.")
    if len(df.columns) < 2:
        raise HTTPException(status_code=422, detail="The dataset must have at least 2 columns.")

    job_id = str(uuid.uuid4())
    data_storage[job_id] = df

    return {
        "message": "File processed successfully.",
        "columns": df.columns.tolist(),
        "rows": df.head().values.tolist(),
        "job_id": job_id
    }


async def preprocess_data(df, task_type, target_column):
    feature_cols = [col for col in df.columns if col != target_column]

    numerical_cols = df[feature_cols].select_dtypes(include=['number']).columns
    categorical_cols = df[feature_cols].select_dtypes(include=['object', 'category']).columns

    if not numerical_cols.empty:
        df[numerical_cols] = df[numerical_cols].fillna(df[numerical_cols].mean())

    if not categorical_cols.empty:
        for col in categorical_cols:
            mode_val = df[col].mode()
            df[col] = df[col].fillna(mode_val[0] if not mode_val.empty else "Unknown")

    if not numerical_cols.empty:
        scaler = StandardScaler()
        df[numerical_cols] = scaler.fit_transform(df[numerical_cols])

    if not categorical_cols.empty:
        df = pd.get_dummies(df, columns=list(categorical_cols), drop_first=True)

    if task_type == 'classification' and target_column in df.columns:
        df[target_column] = df[target_column].astype(str)
        counts = Counter(df[target_column])
        if len(counts) > 1:
            min_class = min(counts, key=counts.get)
            maj_class = max(counts, key=counts.get)
            df_min = df[df[target_column] == min_class]
            df_maj = df[df[target_column] == maj_class]
            df_maj_downsampled = resample(df_maj, replace=False, n_samples=len(df_min), random_state=42)
            df = pd.concat([df_min, df_maj_downsampled]).sample(frac=1).reset_index(drop=True)

    return df


async def train_regression(df, target):
    if not pd.api.types.is_numeric_dtype(df[target]):
        le = LabelEncoder()
        df[target] = le.fit_transform(df[target].astype(str))

    X = df.drop(columns=[target])
    y = df[target]

    if X.shape[1] == 0:
        raise HTTPException(status_code=422, detail="No feature columns remain after preprocessing. Try a different target column.")
    if len(X) < 10:
        raise HTTPException(status_code=422, detail=f"Not enough samples to train ({len(X)} rows after preprocessing). Need at least 10.")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    m1 = LinearRegression().fit(X_train, y_train)
    m2 = DecisionTreeRegressor().fit(X_train, y_train)

    p1, p2 = m1.predict(X_test), m2.predict(X_test)

    res1 = {"name": "Linear Regression", "mae": mean_absolute_error(y_test, p1), "mse": mean_squared_error(y_test, p1), "r2": r2_score(y_test, p1)}
    res2 = {"name": "Decision Tree",     "mae": mean_absolute_error(y_test, p2), "mse": mean_squared_error(y_test, p2), "r2": r2_score(y_test, p2)}

    best = res1["name"] if res1["mse"] <= res2["mse"] else res2["name"]
    return {
        "all_results": [res1, res2],
        "best_model": best,
        "message": f"{best} selected based on lower Mean Squared Error."
    }


async def train_classification(df, target):
    X = df.drop(columns=[target])
    y = df[target].astype(str)

    if X.shape[1] == 0:
        raise HTTPException(status_code=422, detail="No feature columns remain after preprocessing. Try a different target column.")
    if len(X) < 10:
        raise HTTPException(status_code=422, detail=f"Not enough samples to train ({len(X)} rows after preprocessing). Need at least 10.")

    n_classes = y.nunique()
    if n_classes < 2:
        raise HTTPException(status_code=422, detail=f"Target column '{target}' has only one unique value. Classification requires at least 2 classes.")
    if n_classes > 50:
        raise HTTPException(status_code=422, detail=f"Target column '{target}' has {n_classes} unique values. Is this really a classification target?")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    m1 = LogisticRegression(max_iter=1000).fit(X_train, y_train)
    m2 = DecisionTreeClassifier().fit(X_train, y_train)

    p1, p2 = m1.predict(X_test), m2.predict(X_test)

    res1 = {
        "name": "Logistic Regression",
        "accuracy": accuracy_score(y_test, p1),
        "precision": precision_score(y_test, p1, average='macro', zero_division=0),
        "recall": recall_score(y_test, p1, average='macro', zero_division=0),
        "confusion_matrix": confusion_matrix(y_test, p1).tolist()
    }
    res2 = {
        "name": "Decision Tree",
        "accuracy": accuracy_score(y_test, p2),
        "precision": precision_score(y_test, p2, average='macro', zero_division=0),
        "recall": recall_score(y_test, p2, average='macro', zero_division=0),
        "confusion_matrix": confusion_matrix(y_test, p2).tolist()
    }

    best = res1["name"] if res1["accuracy"] >= res2["accuracy"] else res2["name"]
    return {
        "all_results": [res1, res2],
        "best_model": best,
        "message": f"{best} selected based on higher accuracy."
    }


async def train_clustering(df):
    if len(df) < 10:
        raise HTTPException(status_code=422, detail=f"Not enough samples for clustering ({len(df)} rows). Need at least 10.")
    if df.shape[1] == 0:
        raise HTTPException(status_code=422, detail="No feature columns available for clustering after preprocessing.")

    m1 = KMeans(n_clusters=3, n_init=10).fit(df)
    m2 = AgglomerativeClustering(n_clusters=3).fit(df)

    s1 = silhouette_score(df, m1.labels_)
    s2 = silhouette_score(df, m2.labels_)

    res1 = {"name": "K-Means",                 "silhouette": s1}
    res2 = {"name": "Agglomerative Clustering", "silhouette": s2}

    best = res1["name"] if s1 >= s2 else res2["name"]
    return {
        "all_results": [res1, res2],
        "best_model": best,
        "message": f"{best} selected based on higher Silhouette Score."
    }


@router.post("/train")
async def train_pipeline(payload: dict):
    job_id       = payload.get('job_id')
    task_type    = payload.get('task_type')
    target_column = payload.get('target_column')

    if not job_id:
        raise HTTPException(status_code=400, detail="Missing job_id. Please upload a file first.")
    if job_id not in data_storage:
        raise HTTPException(status_code=404, detail="Session expired or data not found. Please re-upload your file.")
    if task_type not in ('regression', 'classification', 'clustering'):
        raise HTTPException(status_code=400, detail=f"Invalid task type '{task_type}'. Must be regression, classification, or clustering.")
    if task_type in ('regression', 'classification') and not target_column:
        raise HTTPException(status_code=400, detail=f"A target column is required for {task_type}.")

    df = data_storage[job_id].copy()

    if task_type in ('regression', 'classification') and target_column not in df.columns:
        raise HTTPException(status_code=400, detail=f"Column '{target_column}' not found in the dataset.")

    try:
        df = await preprocess_data(df, task_type, target_column)

        if task_type == 'regression':
            return await train_regression(df, target_column)
        elif task_type == 'classification':
            return await train_classification(df, target_column)
        elif task_type == 'clustering':
            return await train_clustering(df)

    except HTTPException:
        raise  # let our own clean errors pass through untouched
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred during training: {e}")
    finally:
        if job_id in data_storage:
            del data_storage[job_id]